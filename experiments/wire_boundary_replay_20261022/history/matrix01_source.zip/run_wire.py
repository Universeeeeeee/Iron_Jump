"""Observation-only protocol control; never opens native USB or camera."""
import os
from pathlib import Path
import runpy
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'measurement_boundary_replay_20261022'
sys.path.insert(0, str(BASE))
sys.path.insert(0, sys.argv[1])
import replay_support as r
from wire_source import install

install(r)
runpy.run_path(str(BASE / 'run_mode.py'), run_name=__name__)
